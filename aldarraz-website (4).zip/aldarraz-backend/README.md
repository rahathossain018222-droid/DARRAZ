# Al Darraz — Full-Stack Website

A modern, editorial-style website for **Al Darraz for Men's Tailoring** with a real backend: bookings, an admin CMS, image uploads, and a contact inbox — all running on **plain Node.js with zero npm dependencies** (uses Node's built-in `node:sqlite`, `node:http`, and `node:crypto`).

---

## What's inside

```
aldarraz-backend/
├── server.js          ← the entire backend (one file, no npm installs needed)
├── package.json
├── public/
│   └── index.html     ← the entire frontend (one file)
├── uploads/           ← uploaded photos get stored here
└── aldarraz.db         ← SQLite database (created automatically on first run)
```

## Requirements

- **Node.js 22.5 or newer** (for built-in SQLite support). Check with `node -v`.
- No `npm install` required — everything uses Node's built-in modules.

## Running it

```bash
cd aldarraz-backend
npm start
```

You'll see:

```
✓ Default admin created  username=admin  password=darraz2026
╔══════════════════════════════════════════╗
║   AL DARRAZ — API Server                 ║
╠══════════════════════════════════════════╣
║  http://localhost:4000                   ║
╚══════════════════════════════════════════╝
```

Open **http://localhost:4000** — that's the live site, frontend and backend on the same port.

## Admin access

Click the small gear icon in the top-right of the navigation bar.

| | |
|---|---|
| **Username** | `admin` |
| **Password** | `darraz2026` |

**Change this password immediately** after your first login — use the "Change password" button in the admin bar, or the Settings tab inside the Dashboard.

### What admin mode lets you do
- Click **any text on the page** to edit it directly, in place.
- Hover **any photo** and click "Change photo" to upload a replacement (JPEG/PNG/WebP, processed and stored on the server).
- **Add or remove** service cards, "Why Choose Us" reasons (English and Arabic independently), and branch locations.
- **Save changes** — pushes everything live for all visitors immediately.
- **Reset to defaults** — restores the original Al Darraz content if you want to start over.
- Open the **Dashboard** to see:
  - Booking stats and a live table of appointment requests, with status updates (pending → confirmed → completed/cancelled)
  - Customer messages from the contact form
  - Password management

## How content storage works

There are no environment variables to configure for basic use — everything lives in a single SQLite file (`aldarraz.db`) created automatically next to `server.js`. It contains:

| Table | Purpose |
|---|---|
| `admins` | Login credentials (hashed with PBKDF2, 310,000 iterations) |
| `content` | All editable page text/sections, stored as JSON |
| `images` | Maps each photo "slot" (hero, about, banner, services...) to an uploaded file |
| `bookings` | Every appointment request submitted through the site |
| `messages` | Contact form submissions |
| `audit_log` | A record of every admin action (login, edits, uploads) for accountability |

Back up the whole site by copying `aldarraz.db` and the `uploads/` folder.

## Deploying to a real server / domain

This is a single Node.js process listening on port `4000` (configurable via `PORT` env var). It will run on **any host that supports Node 22+**, including:

- A VPS (DigitalOcean, Linode, Hetzner, AWS EC2) — just `npm start` behind a reverse proxy (Nginx/Caddy) for HTTPS.
- Render, Railway, Fly.io — point them at this repo, build command `none`, start command `npm start`.
- A Qatar-based hosting provider that supports custom Node.js apps.

**It will NOT work on platforms that only serve static files** (e.g. plain GitHub Pages, Netlify static hosting) since this needs a running server process for the booking system, admin login, and image uploads. If you only need the visual site with no backend, ask for the static single-file version instead.

### Example: putting it behind Nginx with HTTPS

```nginx
server {
    listen 80;
    server_name aldarraz.com www.aldarraz.com;

    location / {
        proxy_pass http://localhost:4000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Then use `certbot` for a free SSL certificate.

### Keeping it running permanently

Use a process manager so the server restarts automatically if it crashes or the machine reboots:

```bash
npm install -g pm2      # one-time, needs internet access on your server
pm2 start server.js --name aldarraz
pm2 save
pm2 startup             # follow the printed instructions to enable on boot
```

(Or use a `systemd` service file if you prefer not to install pm2.)

## API reference

All endpoints are prefixed `/api`. Admin-only endpoints require an `Authorization: Bearer <token>` header obtained from `/api/auth/login`.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/login` | — | Log in, returns a JWT |
| POST | `/api/auth/change-password` | ✓ | Change the admin password |
| GET | `/api/auth/verify` | ✓ | Check if a token is still valid |
| GET | `/api/content` | — | Fetch all page content |
| PUT | `/api/content` | ✓ | Save page content (key/value JSON) |
| POST | `/api/images/:slot` | ✓ | Upload a photo (multipart/form-data, field name `image`) |
| GET | `/api/images/:slot` | — | Fetch a photo |
| POST | `/api/bookings` | — | Submit an appointment request |
| GET | `/api/bookings` | ✓ | List bookings (supports `?status=` and `?page=`) |
| PATCH | `/api/bookings/:id` | ✓ | Update a booking's status |
| POST | `/api/messages` | — | Submit a contact form message |
| GET | `/api/messages` | ✓ | List messages |
| PATCH | `/api/messages/:id/read` | ✓ | Mark a message as read |
| GET | `/api/stats` | ✓ | Dashboard summary numbers |
| GET | `/api/audit` | ✓ | Recent admin activity log |

JWTs expire after 8 hours; admins are simply asked to sign in again.

## Security notes

- Passwords are hashed with PBKDF2 (310,000 iterations, SHA-256) — never stored in plain text.
- JWTs are signed with HMAC-SHA256 using a secret generated at first startup (override with the `JWT_SECRET` env var if you want it to survive server restarts with the same secret, otherwise existing sessions just need to log in again after a restart).
- Only JPEG, PNG, and WebP uploads are accepted, capped at 8MB.
- Path traversal is blocked when serving static files.
- Set `JWT_SECRET` as a fixed environment variable in production so admin sessions survive deploys:
  ```bash
  JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))") npm start
  ```

## Customizing further

- All page copy, the services list, "why choose us" reasons, and branch list are stored as data in the browser and synced to the backend — no code editing needed for routine content changes, just use the admin UI.
- To change brand colors, fonts, or layout, edit the `<style>` block at the top of `public/index.html` — CSS custom properties (`--gold-400`, `--bg`, etc.) control the whole palette from one place.
