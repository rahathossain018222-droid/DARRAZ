/**
 * AL DARRAZ — Backend API Server
 * Pure Node.js 22+ (no npm packages needed)
 * Uses: node:sqlite, node:http, node:crypto, node:fs, node:path, node:url
 */

'use strict';

const http       = require('node:http');
const https      = require('node:https');
const fs         = require('node:fs');
const path       = require('node:path');
const crypto     = require('node:crypto');
const url        = require('node:url');
const { DatabaseSync } = require('node:sqlite');

// ─── Config ───────────────────────────────────────────────────────────────────
const PORT        = process.env.PORT        || 4000;
const JWT_SECRET  = process.env.JWT_SECRET  || crypto.randomBytes(32).toString('hex');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const DB_FILE     = path.join(__dirname, 'aldarraz.db');
const MAX_UPLOAD  = 8 * 1024 * 1024; // 8 MB

if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// ─── Database setup ───────────────────────────────────────────────────────────
const db = new DatabaseSync(DB_FILE);
db.exec(`PRAGMA journal_mode=WAL;`);

db.exec(`
  CREATE TABLE IF NOT EXISTS admins (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    pwd_hash TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS content (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS images (
    slot       TEXT PRIMARY KEY,
    filename   TEXT NOT NULL,
    mime_type  TEXT NOT NULL,
    uploaded_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    phone       TEXT NOT NULL,
    email       TEXT,
    service     TEXT NOT NULL,
    branch      TEXT NOT NULL,
    preferred_date TEXT,
    notes       TEXT,
    status      TEXT DEFAULT 'pending',
    created_at  TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    email      TEXT NOT NULL,
    subject    TEXT,
    body       TEXT NOT NULL,
    read       INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_user TEXT,
    action     TEXT,
    detail     TEXT,
    ip         TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// Seed default admin if none exists
const existingAdmin = db.prepare('SELECT id FROM admins LIMIT 1').get();
if (!existingAdmin) {
  const hash = hashPassword('darraz2026');
  db.prepare('INSERT INTO admins (username, pwd_hash) VALUES (?, ?)').run('admin', hash);
  console.log('✓ Default admin created  username=admin  password=darraz2026');
}

// ─── Password hashing (PBKDF2 — built-in) ────────────────────────────────────
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 310000, 32, 'sha256').toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const attempt = crypto.pbkdf2Sync(password, salt, 310000, 32, 'sha256').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(attempt, 'hex'));
}

// ─── JWT (HS256, built-in crypto) ─────────────────────────────────────────────
function signJWT(payload, expiresInSeconds = 28800) {
  const header  = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const claims  = b64url(JSON.stringify({ ...payload, iat: Math.floor(Date.now()/1000), exp: Math.floor(Date.now()/1000) + expiresInSeconds }));
  const sig     = b64url(crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${claims}`).digest());
  return `${header}.${claims}.${sig}`;
}
function verifyJWT(token) {
  try {
    const [header, claims, sig] = token.split('.');
    const expected = b64url(crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${claims}`).digest());
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(claims, 'base64url').toString());
    if (payload.exp < Math.floor(Date.now()/1000)) return null;
    return payload;
  } catch { return null; }
}
function b64url(data) {
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
  return buf.toString('base64url');
}

// ─── HTTP helpers ─────────────────────────────────────────────────────────────
function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function cors(req, res) {
  const origin = req.headers['origin'] || '*';
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,PATCH,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_UPLOAD) { req.destroy(); reject(new Error('Payload too large')); return; }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
function parseJSON(buf) {
  try { return JSON.parse(buf.toString()); } catch { return null; }
}
function requireAuth(req, res) {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) { json(res, 401, { error: 'Unauthorized' }); return null; }
  const payload = verifyJWT(token);
  if (!payload) { json(res, 401, { error: 'Token expired or invalid' }); return null; }
  return payload;
}
function auditLog(user, action, detail, ip) {
  try { db.prepare('INSERT INTO audit_log (admin_user,action,detail,ip) VALUES (?,?,?,?)').run(user, action, detail, ip); } catch {}
}

// ─── Multipart parser (for image uploads, no npm) ────────────────────────────
function parseMultipart(buffer, boundary) {
  const sep = Buffer.from(`--${boundary}`);
  const end = Buffer.from(`--${boundary}--`);
  const parts = [];
  let pos = 0;
  while (pos < buffer.length) {
    const start = bufIndexOf(buffer, sep, pos);
    if (start === -1) break;
    pos = start + sep.length;
    if (buffer.slice(pos, pos + 2).toString() === '--') break;
    if (buffer[pos] === 13) pos += 2; // \r\n
    const headerEnd = bufIndexOf(buffer, Buffer.from('\r\n\r\n'), pos);
    if (headerEnd === -1) break;
    const headerStr = buffer.slice(pos, headerEnd).toString();
    pos = headerEnd + 4;
    const nextBound = bufIndexOf(buffer, sep, pos);
    const bodyEnd = nextBound === -1 ? buffer.length : nextBound - 2;
    const body = buffer.slice(pos, bodyEnd);
    pos = nextBound;
    const nameMatch = headerStr.match(/name="([^"]+)"/);
    const filenameMatch = headerStr.match(/filename="([^"]+)"/);
    const ctMatch = headerStr.match(/Content-Type:\s*([^\r\n]+)/i);
    parts.push({
      name: nameMatch ? nameMatch[1] : null,
      filename: filenameMatch ? filenameMatch[1] : null,
      contentType: ctMatch ? ctMatch[1].trim() : 'application/octet-stream',
      data: body
    });
  }
  return parts;
}
function bufIndexOf(buf, search, start = 0) {
  for (let i = start; i <= buf.length - search.length; i++) {
    let found = true;
    for (let j = 0; j < search.length; j++) {
      if (buf[i + j] !== search[j]) { found = false; break; }
    }
    if (found) return i;
  }
  return -1;
}

// ─── Router ───────────────────────────────────────────────────────────────────
const routes = [];
function route(method, pattern, handler) {
  routes.push({ method, pattern: new RegExp('^' + pattern.replace(/:([^/]+)/g,'(?<$1>[^/]+)') + '$'), handler });
}

// Auth
route('POST', '/api/auth/login', async (req, res) => {
  const body = parseJSON(await readBody(req));
  if (!body?.username || !body?.password) return json(res, 400, { error: 'username and password required' });
  const admin = db.prepare('SELECT * FROM admins WHERE username=?').get(body.username);
  if (!admin || !verifyPassword(body.password, admin.pwd_hash)) return json(res, 401, { error: 'Invalid credentials' });
  const token = signJWT({ sub: admin.id, username: admin.username });
  auditLog(admin.username, 'login', '', req.socket.remoteAddress);
  json(res, 200, { token, username: admin.username });
});

route('POST', '/api/auth/change-password', async (req, res) => {
  const user = requireAuth(req, res); if (!user) return;
  const body = parseJSON(await readBody(req));
  if (!body?.current || !body?.newPassword || body.newPassword.length < 6) return json(res, 400, { error: 'Provide current password and a new password of at least 6 characters' });
  const admin = db.prepare('SELECT * FROM admins WHERE id=?').get(user.sub);
  if (!admin || !verifyPassword(body.current, admin.pwd_hash)) return json(res, 401, { error: 'Current password is wrong' });
  db.prepare('UPDATE admins SET pwd_hash=? WHERE id=?').run(hashPassword(body.newPassword), user.sub);
  auditLog(user.username, 'change-password', '', req.socket.remoteAddress);
  json(res, 200, { ok: true });
});

route('GET', '/api/auth/verify', async (req, res) => {
  const user = requireAuth(req, res); if (!user) return;
  json(res, 200, { ok: true, username: user.username });
});

// Content
route('GET', '/api/content', async (req, res) => {
  const rows = db.prepare('SELECT key, value FROM content').all();
  const out = {};
  rows.forEach(r => {
    try { out[r.key] = JSON.parse(r.value); } catch { out[r.key] = r.value; }
  });
  json(res, 200, out);
});

route('PUT', '/api/content', async (req, res) => {
  const user = requireAuth(req, res); if (!user) return;
  const body = parseJSON(await readBody(req));
  if (!body || typeof body !== 'object') return json(res, 400, { error: 'Expected JSON object' });
  const upsert = db.prepare(`INSERT INTO content (key, value, updated_at) VALUES (?,?,datetime('now')) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at`);
  try {
    db.exec('BEGIN');
    for (const [k, v] of Object.entries(body)) {
      upsert.run(k, typeof v === 'string' ? v : JSON.stringify(v));
    }
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  auditLog(user.username, 'content-update', `keys: ${Object.keys(body).join(',')}`, req.socket.remoteAddress);
  json(res, 200, { ok: true, updated: Object.keys(body).length });
});

route('GET', '/api/content/:key', async (req, res, params) => {
  const row = db.prepare('SELECT value FROM content WHERE key=?').get(params.key);
  if (!row) return json(res, 404, { error: 'Key not found' });
  try { json(res, 200, { key: params.key, value: JSON.parse(row.value) }); }
  catch { json(res, 200, { key: params.key, value: row.value }); }
});

// Images
route('POST', '/api/images/:slot', async (req, res, params) => {
  const user = requireAuth(req, res); if (!user) return;
  const ct = req.headers['content-type'] || '';
  const boundaryMatch = ct.match(/boundary=([^\s;]+)/);
  if (!boundaryMatch) return json(res, 400, { error: 'Expected multipart/form-data' });
  const buffer = await readBody(req);
  const parts = parseMultipart(buffer, boundaryMatch[1]);
  const filePart = parts.find(p => p.filename);
  if (!filePart) return json(res, 400, { error: 'No file found in upload' });
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowed.includes(filePart.contentType)) return json(res, 400, { error: 'Only JPEG, PNG or WebP allowed' });
  const ext = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' }[filePart.contentType];
  const filename = `${params.slot}_${Date.now()}${ext}`;
  const filepath = path.join(UPLOADS_DIR, filename);
  // Clean up old file for this slot
  const old = db.prepare('SELECT filename FROM images WHERE slot=?').get(params.slot);
  if (old) { try { fs.unlinkSync(path.join(UPLOADS_DIR, old.filename)); } catch {} }
  fs.writeFileSync(filepath, filePart.data);
  db.prepare(`INSERT INTO images (slot, filename, mime_type, uploaded_at) VALUES (?,?,?,datetime('now')) ON CONFLICT(slot) DO UPDATE SET filename=excluded.filename, mime_type=excluded.mime_type, uploaded_at=excluded.uploaded_at`).run(params.slot, filename, filePart.contentType);
  auditLog(user.username, 'image-upload', `slot=${params.slot} file=${filename}`, req.socket.remoteAddress);
  json(res, 200, { ok: true, slot: params.slot, url: `/api/images/${params.slot}` });
});

route('GET', '/api/images/:slot', async (req, res, params) => {
  const row = db.prepare('SELECT filename, mime_type FROM images WHERE slot=?').get(params.slot);
  if (!row) return json(res, 404, { error: 'Image not found' });
  const filepath = path.join(UPLOADS_DIR, row.filename);
  if (!fs.existsSync(filepath)) return json(res, 404, { error: 'File missing' });
  const data = fs.readFileSync(filepath);
  res.writeHead(200, { 'Content-Type': row.mime_type, 'Content-Length': data.length, 'Cache-Control': 'public, max-age=86400' });
  res.end(data);
});

// Bookings
route('POST', '/api/bookings', async (req, res) => {
  const body = parseJSON(await readBody(req));
  if (!body?.name || !body?.phone || !body?.service || !body?.branch) return json(res, 400, { error: 'name, phone, service, branch are required' });
  const result = db.prepare('INSERT INTO bookings (name,phone,email,service,branch,preferred_date,notes) VALUES (?,?,?,?,?,?,?)').run(body.name, body.phone, body.email||'', body.service, body.branch, body.preferred_date||'', body.notes||'');
  json(res, 201, { ok: true, id: result.lastInsertRowid, message: 'Booking received. We will contact you to confirm.' });
});

route('GET', '/api/bookings', async (req, res) => {
  const user = requireAuth(req, res); if (!user) return;
  const parsed = url.parse(req.url, true);
  const status = parsed.query.status;
  const page   = Math.max(1, parseInt(parsed.query.page) || 1);
  const limit  = 20;
  const offset = (page - 1) * limit;
  const rows = status
    ? db.prepare('SELECT * FROM bookings WHERE status=? ORDER BY created_at DESC LIMIT ? OFFSET ?').all(status, limit, offset)
    : db.prepare('SELECT * FROM bookings ORDER BY created_at DESC LIMIT ? OFFSET ?').all(limit, offset);
  const total = status
    ? db.prepare('SELECT COUNT(*) as c FROM bookings WHERE status=?').get(status).c
    : db.prepare('SELECT COUNT(*) as c FROM bookings').get().c;
  json(res, 200, { bookings: rows, total, page, pages: Math.ceil(total / limit) });
});

route('PATCH', '/api/bookings/:id', async (req, res, params) => {
  const user = requireAuth(req, res); if (!user) return;
  const body = parseJSON(await readBody(req));
  const allowed = ['pending','confirmed','completed','cancelled'];
  if (!allowed.includes(body?.status)) return json(res, 400, { error: `status must be one of: ${allowed.join(', ')}` });
  db.prepare('UPDATE bookings SET status=? WHERE id=?').run(body.status, params.id);
  auditLog(user.username, 'booking-update', `id=${params.id} status=${body.status}`, req.socket.remoteAddress);
  json(res, 200, { ok: true });
});

// Messages (contact form)
route('POST', '/api/messages', async (req, res) => {
  const body = parseJSON(await readBody(req));
  if (!body?.name || !body?.email || !body?.body) return json(res, 400, { error: 'name, email, body required' });
  const result = db.prepare('INSERT INTO messages (name,email,subject,body) VALUES (?,?,?,?)').run(body.name, body.email, body.subject||'', body.body);
  json(res, 201, { ok: true, id: result.lastInsertRowid });
});

route('GET', '/api/messages', async (req, res) => {
  const user = requireAuth(req, res); if (!user) return;
  const parsed = url.parse(req.url, true);
  const unread = parsed.query.unread === '1';
  const rows = unread
    ? db.prepare('SELECT * FROM messages WHERE read=0 ORDER BY created_at DESC').all()
    : db.prepare('SELECT * FROM messages ORDER BY created_at DESC LIMIT 50').all();
  json(res, 200, { messages: rows });
});

route('PATCH', '/api/messages/:id/read', async (req, res, params) => {
  const user = requireAuth(req, res); if (!user) return;
  db.prepare('UPDATE messages SET read=1 WHERE id=?').run(params.id);
  json(res, 200, { ok: true });
});

// Dashboard stats
route('GET', '/api/stats', async (req, res) => {
  const user = requireAuth(req, res); if (!user) return;
  const bookings_total   = db.prepare('SELECT COUNT(*) as c FROM bookings').get().c;
  const bookings_pending = db.prepare("SELECT COUNT(*) as c FROM bookings WHERE status='pending'").get().c;
  const bookings_today   = db.prepare("SELECT COUNT(*) as c FROM bookings WHERE DATE(created_at)=DATE('now')").get().c;
  const messages_unread  = db.prepare('SELECT COUNT(*) as c FROM messages WHERE read=0').get().c;
  const recent_bookings  = db.prepare("SELECT * FROM bookings ORDER BY created_at DESC LIMIT 5").all();
  json(res, 200, { bookings_total, bookings_pending, bookings_today, messages_unread, recent_bookings });
});

// Audit log
route('GET', '/api/audit', async (req, res) => {
  const user = requireAuth(req, res); if (!user) return;
  const rows = db.prepare('SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 100').all();
  json(res, 200, { log: rows });
});

// ─── Request handler ──────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  cors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // Serve static frontend
  if (!req.url.startsWith('/api/')) {
    const publicDir = path.join(__dirname, 'public');
    let filePath = path.join(publicDir, req.url === '/' ? 'index.html' : req.url);
    // security: prevent path traversal
    if (!filePath.startsWith(publicDir)) { res.writeHead(403); res.end('Forbidden'); return; }
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath);
      const mime = { '.html':'text/html', '.js':'application/javascript', '.css':'text/css', '.png':'image/png', '.jpg':'image/jpeg', '.svg':'image/svg+xml', '.ico':'image/x-icon', '.woff2':'font/woff2' }[ext] || 'application/octet-stream';
      const data = fs.readFileSync(filePath);
      res.writeHead(200, { 'Content-Type': mime, 'Content-Length': data.length });
      res.end(data);
    } else {
      // SPA fallback
      const indexPath = path.join(publicDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        const data = fs.readFileSync(indexPath);
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
      } else {
        res.writeHead(404); res.end('Not found');
      }
    }
    return;
  }

  // Route matching
  const parsedUrl = url.parse(req.url);
  const pathname  = parsedUrl.pathname;
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const match = pathname.match(r.pattern);
    if (match) {
      try {
        await r.handler(req, res, match.groups || {});
      } catch (err) {
        console.error(`[ERROR] ${req.method} ${req.url}:`, err.message);
        if (!res.headersSent) json(res, 500, { error: 'Internal server error' });
      }
      return;
    }
  }
  json(res, 404, { error: `No route: ${req.method} ${pathname}` });
});

server.listen(PORT, () => {
  console.log(`\n╔══════════════════════════════════════════╗`);
  console.log(`║   AL DARRAZ — API Server                 ║`);
  console.log(`╠══════════════════════════════════════════╣`);
  console.log(`║  http://localhost:${PORT}                  ║`);
  console.log(`║  DB: ${path.basename(DB_FILE)}                       ║`);
  console.log(`║  Default login: admin / darraz2026       ║`);
  console.log(`╚══════════════════════════════════════════╝\n`);
});

module.exports = server;
